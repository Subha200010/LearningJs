function x(a,b){
    console.log(a+b);
}
x(2,2)
x(1,2,3)
x(1)
x("hi","hello")
x(["hi","hello","who r u  "])
x("hi ")




console.log(y);  // [Function: y] dunction body
// console.log(y());  // hello 
y() //
function y(){
    // console.log("hello");
    return "hi"
    console.log("bye");
}
y()
console.log(y); //function body
console.log(y());  //hi