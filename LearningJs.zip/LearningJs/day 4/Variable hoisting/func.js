a;
console.log(a); //undefined
var a;
console.log(a); //undefined
a=10
console.log(a); //10

// b=10;
// console.log(b);
// let b;
// console.log(b);
//this is not working beacause it only work for var ...and for let & const if we do hoistion data will go to TDZ(Temporary Dead Zone)


/* ----------------------------------->to run only js file<-------------------------------------------------  */
                                 /* 1.open terminal in vs code 
                                  2.write node filename.js  
                         3.example for this file ---> node function.js  */