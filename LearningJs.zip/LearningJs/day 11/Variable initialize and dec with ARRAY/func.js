let skills=["html","css","js"]
// we initialize and declare like below with the help of array
let[web1,web2,web3]=skills

