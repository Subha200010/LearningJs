// console.log('hello');
// let a=10
// function x(){
//     let b=20
//     console.log(b);
//     console.log(a);
// }
// console.log(a);
// function y(){
//     let c=30
//     console.log(c+a);
// }
// y()
// x()
// console.log('end');

 /*                                                 */

 console.log('Hello');
 let a=10
 function x(){
    let a='hi'
    console.log(a);
}
x()
function y(){
        let b=20
        console.log(b);
    }
    // console.log(b);
    y()
    console.log("end");

