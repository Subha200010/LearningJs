console.log("hello");

function x() {
    let a=20
    console.log(a);
}
function y() {
    let b=40
    console.log(b);
}

y()
x()