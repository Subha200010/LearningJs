
// let b=document.getElementById("clickme")
// console.log(b);
// b.addEventListener("click",function name() {
//     console.log("hi");
// })
function y(){ 
let count=0;
document.getElementById("clickme").addEventListener("click",function x(){
    console.log("button click  " + ++count);
})
}
y()