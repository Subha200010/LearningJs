
function  x(){
    var b=10
 c()
 function c(){   // c function lexically sitting inside a() function
    console.log(b);
 }   
}
x()
//whenever execution context is created lexical enviorment will create

// lexical enviroment = local memory +  ref of lexical enviroment of its parent

// the whole chain of lexical enviroment is known as scope chain




