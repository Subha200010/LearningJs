// function x(){
//     var a=10;
//     function y(){
//         console.log(a);
//     }
//     y()
// }
// x();

// function x(){
//     var a=10;
//    return function y(){
//         console.log(a);
//     }

// }
// let z=x();
// // console.log(z);
// z();

// function x(){
//     var a=10;
//    return function y(){
//         // var a=100;
//         console.log(a);
//     }
//      a=200 
// }
// let z=x();
// z()
var a=100;
function z(){
    //  a=101
    function x(){
        // var a=200
        function y(){
         console.log(a);
        //  console.log(b);
        a=500

        }
        y()
    }
    x()
}
console.log(a);

z()
