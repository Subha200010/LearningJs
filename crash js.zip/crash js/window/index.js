// any thing we declare here is known as global memory space 
// anyting we declare inside a function know as local memory space

// window is global object 
// this also refer to thw window object 
// window === this ---->true

var a=10
function x(){
    var x=10;
}
console.log(window.a);
console.log(a);
console.log(this.a);