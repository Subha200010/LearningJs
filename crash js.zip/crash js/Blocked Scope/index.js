
  

{
    // console.log(a);
    const a=10
    let b=20
    var c=30
}

console.log(c);
// console.log(b);
// console.log(a);


var x=100
var x=10   // it not give error in var 
console.log(x);


var y =200  // global spce
{
    var y=10 // local spec but bcs of var it reinitialize into 10
    console.log(y); //10
}
console.log(y); // 10 ----> its the reason -->it know as variable shadowing in js

let z= 300
{
    let z=30;
    console.log(z);
}
console.log(z); // 300 ---> it not possible for let or const

let xy=200;
function xyz(){
    var xy=20;
    console.log(xy);
}
console.log(xy);
xyz()