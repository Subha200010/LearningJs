// console.log(a); // ReferenceError: Cannot access 'a' before initialization

let a=10

//let a=200 -----> SyntaxError


// variable hoisting is only possible for var 
console.log(b); // ----> undefined
var b=10

var b=100  // with var we re declre same variables


// const c   //-----> for the const variable we must have to intialize int it declaration line


const c=100
console.log(c);

// console.log(d); ----->ReferenceError: d is not defined

// const e ------------ SyntaxError: Missing initializer in const declaration