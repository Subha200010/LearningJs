a("hello world")
console.log(b);
// console.log(b());
//b() // ---------------------------------->

// statement function or normal function
function a(param) {
   console.log(param); 
}

//function with expression or expression function

var b= function () {
    console.log("hi");
}
console.log(b);
b()

// named functiion expression

let c=function xyz() {
    console.log("hi named fuction");
}
c()

// 1st class function
function y() {
    console.log("hiiiiiiiiiiii");
}
function x(params) {
    params()
}

x(y)

let t = function () {
   return function name() {
    
   }
}

// example of call back funtion
setTimeout(function(){
    console.log("timer");
},1000)
