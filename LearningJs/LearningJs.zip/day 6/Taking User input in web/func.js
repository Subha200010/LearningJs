// let name=prompt("Enter your name")
// let age=prompt("Enter your age")
// let role=prompt("Enter your job role")
// console.log(`my name is ${name} ,I am ${age} years old and i am working as a ${role}`);

// console.log("my name is "+ name +" ,I am " + age + " years old and i am working as a "+ role);

// console.log(`my name has ${name.length} length`);


let number1=Number.parseInt(prompt("Enter 1st number"))
let number2=Number.parseInt(prompt("Enter 2nd number"))
// let sum=number1+number2
console.log(`the addition of ${number1} & ${number2} is ${number1+number2}`);
console.log(`the subtraction of ${number1} & ${number2} is ${number1-number2}`);
console.log(`the multification of ${number1} & ${number2} is ${number1*number2}`);
console.log(`the divion of ${number1} & ${number2} is ${number1/number2}`);
