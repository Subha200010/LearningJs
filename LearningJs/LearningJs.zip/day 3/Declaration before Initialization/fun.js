console.log("hi");
var a=10
var a 
console.log(a);
var b 
console.log(b);
b=10 
console.log(a+b);