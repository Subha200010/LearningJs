let web1="HTML" 
let web2='CSS'
let web3=`Js`

console.log(web1+" is used for structure \n "+web2+"id used for style\n" +web3+" is used for func");

console.log(`${web1} is used for structure
${web2}  is used for style
${web3}  is used for func` );



